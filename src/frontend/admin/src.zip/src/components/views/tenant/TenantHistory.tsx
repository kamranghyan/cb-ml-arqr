'use client';

import { useState, useEffect, useCallback } from 'react';
import { Receipt, Loader2, RefreshCw, AlertCircle, Search } from 'lucide-react';
import BranchPicker from '@/components/BranchPicker';
import {
  fetchMyBranches, fetchOrders, revenueOf, derivedStatus,
  type Branch, type BranchOrder,
} from '@/lib/tenant-api';
import {
  money, STATUS_LABEL, STATUS_COLOR, orderTypeOf, destinationOf,
  ORDER_TYPE_LABEL, ORDER_TYPE_COLOR,
  type OrderStatus, type OrderType,
} from '@/lib/support-api';

const C = {
  red: '#E1251B', bg: '#FFF8F1', white: '#fff', border: '#F0E8E0',
  text: '#1A1A1A', muted: '#687780', subtle: '#9CA3AF', green: '#0F9D58',
};

const RANGES = [
  { label: 'Last 4 hours',  hours: 4  },
  { label: 'Last 12 hours', hours: 12 },
  { label: 'Last 24 hours', hours: 24 },
];

const FILTERS: (OrderStatus | 'all')[] =
  ['all', 'delivered', 'cancelled', 'ready', 'preparing', 'pending'];

export default function TenantHistory() {
  const [branches, setBranches] = useState<Branch[]>([]);
  const [branchId, setBranchId] = useState('');
  const [hours, setHours]       = useState(24);
  const [orders, setOrders]     = useState<BranchOrder[]>([]);
  const [loadingB, setLoadB]    = useState(true);
  const [loadingO, setLoadO]    = useState(false);
  const [error, setError]       = useState('');
  const [filter, setFilter]     = useState<OrderStatus | 'all'>('all');
  const [query, setQuery]       = useState('');
  const [typeFilter, setTypeFilter] = useState<OrderType | 'all'>('all');

  useEffect(() => {
    fetchMyBranches()
      .then(setBranches)
      .catch(e => setError(e?.message ?? 'Could not load your restaurants'))
      .finally(() => setLoadB(false));
  }, []);

  const load = useCallback(async () => {
    if (branches.length === 0) return;
    setLoadO(true); setError('');
    try { setOrders(await fetchOrders(branches, branchId, hours)); }
    catch (e: any) { setError(e?.message ?? 'Could not load order history'); }
    finally { setLoadO(false); }
  }, [branches, branchId, hours]);

  useEffect(() => { load(); }, [load]);

  const shown = orders
    .filter(o => filter === 'all' || derivedStatus(o) === filter)
    .filter(o => typeFilter === 'all' || orderTypeOf(o) === typeFilter)
    .filter(o => {
      if (!query.trim()) return true;
      const q = query.toLowerCase();
      return (
        o.orderId.toLowerCase().includes(q) ||
        (o.tableId ?? '').toLowerCase().includes(q) ||
        (o.deliveryAddress ?? '').toLowerCase().includes(q) ||
        o.branchName.toLowerCase().includes(q) ||
        (o.lineItems ?? []).some(li => li.name.toLowerCase().includes(q))
      );
    })
    .sort((a, b) => (b.placedAt ?? '').localeCompare(a.placedAt ?? ''));

  const currency  = branches[0]?.currencyCode || 'PKR';
  const showBranch = branchId === '' && branches.length > 1;

  return (
    <div style={{ padding: 24, maxWidth: 1150, margin: '0 auto' }}>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 800, color: C.text, margin: '0 0 4px' }}>
            Order History
          </h1>
          <p style={{ color: C.muted, fontSize: 14, margin: 0 }}>
            Everything your restaurants have served recently.
          </p>
        </div>
        <button onClick={load} style={ghost}><RefreshCw size={14} /> Refresh</button>
      </div>

      <BranchPicker branches={branches} value={branchId}
                    onChange={setBranchId} loading={loadingB} />

      {!loadingB && branches.length > 0 && (
        <>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap', marginBottom: 16 }}>
            <select value={hours} onChange={e => setHours(Number(e.target.value))} style={select}>
              {RANGES.map(r => <option key={r.hours} value={r.hours}>{r.label}</option>)}
            </select>

            <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
              {FILTERS.map(f => (
                <button key={f} onClick={() => setFilter(f)} style={{
                  ...chip,
                  background: filter === f ? C.red : '#fff',
                  color:      filter === f ? '#fff' : C.muted,
                  borderColor: filter === f ? C.red : C.border,
                }}>
                  {f === 'all' ? 'All' : STATUS_LABEL[f]}
                </button>
              ))}
            </div>

            <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
              {(['all', 'dine_in', 'pickup', 'delivery'] as const).map(t => (
                <button key={t} onClick={() => setTypeFilter(t)} style={{
                  ...chip,
                  background: typeFilter === t ? C.text : '#fff',
                  color:      typeFilter === t ? '#fff' : C.muted,
                  borderColor: typeFilter === t ? C.text : C.border,
                }}>
                  {t === 'all' ? 'Any type' : ORDER_TYPE_LABEL[t]}
                </button>
              ))}
            </div>

            <div style={{ position: 'relative', marginLeft: 'auto' }}>
              <Search size={14} color={C.subtle} style={{ position: 'absolute', left: 10, top: 9 }} />
              <input value={query} onChange={e => setQuery(e.target.value)}
                     placeholder="Table, item or branch…"
                     style={{ ...input, paddingLeft: 30, width: 230 }} />
            </div>
          </div>

          {loadingO && (
            <div style={{ padding: 60, textAlign: 'center', color: C.muted }}>
              <Loader2 size={22} style={{ animation: 'spin 1s linear infinite' }} /> Loading…
            </div>
          )}

          {!loadingO && error && (
            <div style={{ padding: 40, textAlign: 'center', color: C.red }}>
              <AlertCircle size={20} /> {error}
            </div>
          )}

          {!loadingO && !error && (
            <>
              <div style={{ display: 'flex', gap: 12, marginBottom: 16, flexWrap: 'wrap' }}>
                <Stat label="Orders"    value={String(shown.length)} />
                <Stat label="Revenue"   value={money(revenueOf(shown), currency)} accent={C.green} />
                <Stat label="Cancelled" value={String(shown.filter(o => derivedStatus(o) === 'cancelled').length)} />
              </div>

              {shown.length === 0 ? (
                <div style={{ padding: 60, textAlign: 'center', color: C.subtle }}>
                  <Receipt size={28} style={{ opacity: 0.4, marginBottom: 8 }} />
                  <p style={{ margin: 0, fontWeight: 600, color: C.muted }}>Nothing here</p>
                  <p style={{ margin: '4px 0 0', fontSize: 13 }}>
                    {query || filter !== 'all'
                      ? 'No orders match those filters.'
                      : 'No orders in this window.'}
                  </p>
                </div>
              ) : (
                <div style={{ border: `1px solid ${C.border}`, borderRadius: 12, overflow: 'hidden' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                    <thead style={{ background: C.bg }}>
                      <tr>
                        <th style={th}>Placed</th>
                        {showBranch && <th style={th}>Restaurant</th>}
                        <th style={th}>Type</th><th style={th}>Going to</th><th style={th}>Items</th>
                        <th style={th}>Total</th><th style={th}>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {shown.map(o => {
                        const s = derivedStatus(o);
                        const n = (o.lineItems ?? []).reduce((x, li) => x + li.quantity, 0);
                        return (
                          <tr key={o.orderId} style={{ borderTop: `1px solid ${C.border}` }}>
                            <td style={{ ...cell, whiteSpace: 'nowrap' }}>
                              {o.placedAt ? new Date(o.placedAt).toLocaleString() : '—'}
                            </td>
                            {showBranch && <td style={{ ...cell, color: C.muted }}>{o.branchName}</td>}
                            <td style={cell}>
                              <span style={{
                                fontSize: 11, fontWeight: 700, textTransform: 'uppercase',
                                letterSpacing: 0.4, padding: '3px 8px', borderRadius: 6,
                                background: `${ORDER_TYPE_COLOR[orderTypeOf(o)]}15`,
                                color: ORDER_TYPE_COLOR[orderTypeOf(o)],
                              }}>{ORDER_TYPE_LABEL[orderTypeOf(o)]}</span>
                            </td>
                            <td style={{ ...cell, color: C.muted }}>{destinationOf(o)}</td>
                            <td style={{ ...cell, color: C.muted }}>
                              {n} item{n === 1 ? '' : 's'}
                              <span style={{ color: C.subtle, fontSize: 12 }}>
                                {' · '}{(o.lineItems ?? []).slice(0, 2).map(li => li.name).join(', ')}
                                {(o.lineItems ?? []).length > 2 ? '…' : ''}
                              </span>
                            </td>
                            <td style={{ ...cell, fontWeight: 700 }}>
                              {money(o.totalAmountMinorUnits, o.currency)}
                            </td>
                            <td style={cell}>
                              <span style={{
                                fontSize: 11, fontWeight: 700, textTransform: 'uppercase',
                                letterSpacing: 0.5, padding: '3px 8px', borderRadius: 6,
                                background: `${STATUS_COLOR[s]}15`, color: STATUS_COLOR[s],
                              }}>{STATUS_LABEL[s]}</span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </>
          )}
        </>
      )}
    </div>
  );
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: string }) {
  return (
    <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 12, padding: '10px 18px', minWidth: 120 }}>
      <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase', color: C.subtle }}>{label}</div>
      <div style={{ fontSize: 20, fontWeight: 800, color: accent ?? C.text }}>{value}</div>
    </div>
  );
}

const ghost: React.CSSProperties = {
  display: 'inline-flex', alignItems: 'center', gap: 6, padding: '8px 12px',
  border: `1px solid ${C.border}`, borderRadius: 8, background: '#fff',
  fontWeight: 600, fontSize: 13, cursor: 'pointer', color: C.text,
};
const chip: React.CSSProperties = {
  padding: '6px 12px', borderRadius: 20, border: `1px solid ${C.border}`,
  fontSize: 12, fontWeight: 700, cursor: 'pointer',
};
const select: React.CSSProperties = {
  padding: '7px 10px', border: `1px solid ${C.border}`, borderRadius: 8,
  fontSize: 13, background: '#fff', color: C.text, cursor: 'pointer',
};
const input: React.CSSProperties = {
  padding: '8px 11px', border: `1px solid ${C.border}`, borderRadius: 8,
  fontSize: 13, boxSizing: 'border-box', background: '#fff',
};
const cell: React.CSSProperties = { padding: '11px 12px', fontSize: 14, color: C.text };
const th: React.CSSProperties = {
  padding: '10px 12px', fontSize: 11, fontWeight: 700, letterSpacing: 1,
  textTransform: 'uppercase', color: C.subtle, textAlign: 'left',
};
